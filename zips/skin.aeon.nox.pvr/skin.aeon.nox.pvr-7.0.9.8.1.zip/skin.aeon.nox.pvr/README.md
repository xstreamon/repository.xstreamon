# Aeon Nox 5: SiLVO
A modded version of [Aeon Nox 5](http://forum.kodi.tv/showthread.php?tid=183504)

**Branches guide:**
 - **leia:** Kodi v18 Codename Leia
 - **pvr:** Kodi v18 Codename Leia - PVRMod
 - **master:** Kodi v19 Codename Matrix
 
*Check the [Aeon Nox 5: SiLVO thread](http://forum.kodi.tv/showthread.php?tid=210069) for more information and support*

**ALL OTHER BRANCHES SHOULD NOT BE USED OR INSTALLED**
