#!bash

cd /root/repo/addons/plugin.video.xstream
git pull upstream nightly
git push